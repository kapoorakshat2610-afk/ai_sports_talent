import 'dart:convert';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/session_model.dart';
import '../repositories/session_repository.dart';
import 'athlete_dashboard.dart';
import 'compare_sessions_screen.dart';
import 'performance_analytics_screen.dart';
import 'result_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final SessionRepository _repository = SessionRepository();

  List<SessionModel> sessions = [];
  List<Map<String, dynamic>> history = [];

  String selectedAthlete = "All";
  List<String> athleteList = ["All"];

  bool isLoading = true;
  bool isSyncing = false;

  @override
  void initState() {
    super.initState();
    _loadSessions();
  }

  double _toDouble(dynamic value) {
    return double.tryParse(
          value?.toString() ?? "",
        ) ??
        0.0;
  }

  Color _levelColor(String level) {
    final normalized = level.toLowerCase();

    if (normalized == "beginner") {
      return Colors.red;
    }

    if (normalized == "intermediate") {
      return Colors.orange;
    }

    if (normalized == "advanced") {
      return Colors.green;
    }

    return Colors.grey;
  }

  int _calcScore(Map<String, dynamic> data) {
    final storedScore = _toDouble(
      data["overall_score"],
    );

    if (storedScore > 0) {
      return storedScore.round().clamp(0, 100);
    }

    const double ideal = 165;
    final knee = _toDouble(
      data["average_knee_angle"],
    );

    if (knee == 0) {
      return 0;
    }

    final difference = (ideal - knee).abs();

    double score = 100 - (difference * 2);

    if (score < 0) {
      score = 0;
    }

    if (score > 100) {
      score = 100;
    }

    return score.round();
  }

  List<SessionModel> get filteredHistory {
    if (selectedAthlete == "All") {
      return sessions;
    }

    return sessions.where((session) {
      return session.athlete == selectedAthlete;
    }).toList();
  }

  Future<void> _loadSessions() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final loaded = await _repository.getSessions();

      if (!mounted) return;

      _updateSessionState(loaded);

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        sessions = [];
        athleteList = ["All"];
        selectedAthlete = "All";
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Unable to load history: $e",
          ),
        ),
      );
    }
  }

  void _updateSessionState(
    List<SessionModel> loaded,
  ) {
    final names = loaded
        .map((session) => session.athlete.trim())
        .where((name) => name.isNotEmpty)
        .toSet()
        .toList();

    names.sort();

    if (!names.contains("All")) {
      names.insert(0, "All");
    }

    sessions = loaded;
    athleteList = names;

    if (!athleteList.contains(selectedAthlete)) {
      selectedAthlete = "All";
    }
  }

  Future<void> _syncFromBackend() async {
    if (isSyncing) return;

    setState(() {
      isSyncing = true;
    });

    try {
      final synced =
          await _repository.syncFromBackend();

      if (!mounted) return;

      setState(() {
        _updateSessionState(synced);
        isSyncing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Synced ${synced.length} session(s) from backend.",
          ),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isSyncing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Sync failed: $e",
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _migrateLocalHistory() async {
    if (isSyncing) return;

    setState(() {
      isSyncing = true;
    });

    try {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Uploading local history...",
          ),
          duration: Duration(seconds: 2),
        ),
      );

      final migrated =
          await _repository.migrateLocalSessionsToBackend();

      final updated =
          await _repository.getSessions();

      if (!mounted) return;

      setState(() {
        _updateSessionState(updated);
        isSyncing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            migrated > 0
                ? "Uploaded $migrated local session(s) successfully."
                : "No new local sessions found.",
          ),
          backgroundColor:
              migrated > 0 ? Colors.green : null,
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isSyncing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Upload failed: $e",
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _loadLegacyHistory() async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      final legacy = prefs.getStringList("history") ?? [];

      final parsed =
          <Map<String, dynamic>>[];

      for (final item in legacy) {
        try {
          final decoded = jsonDecode(item);

          if (decoded is Map) {
            parsed.add(
              Map<String, dynamic>.from(decoded),
            );
          }
        } catch (_) {}
      }

      if (!mounted) return;

      setState(() {
        history = parsed;
      });
    } catch (_) {}
  }

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            "Clear Local History?",
          ),
          content: const Text(
            "This removes the local cached history from this device. "
            "Backend sessions are not deleted.",
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text("Clear"),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await _repository.deleteAll();

      final prefs =
          await SharedPreferences.getInstance();

      await prefs.remove("history");
      await prefs.remove(
        "runner_analysis_sessions",
      );

      if (!mounted) return;

      setState(() {
        sessions = [];
        history = [];
        athleteList = ["All"];
        selectedAthlete = "All";
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Local history cleared.",
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Unable to clear local history: $e",
          ),
        ),
      );
    }
  }

  Widget _buildGraph() {
    final dataList = filteredHistory;

    if (dataList.length < 2) {
      return const SizedBox(
        height: 200,
        child: Center(
          child: Text(
            "Add more sessions to see the graph.",
          ),
        ),
      );
    }

    final spots =
        dataList.asMap().entries.map((entry) {
      final score = _calcScore(
        entry.value.metrics,
      );

      return FlSpot(
        entry.key.toDouble(),
        score.toDouble(),
      );
    }).toList();

    return SizedBox(
      height: 200,
      child: LineChart(
        LineChartData(
          titlesData:
              const FlTitlesData(show: false),
          borderData:
              FlBorderData(show: false),
          gridData:
              const FlGridData(show: false),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              barWidth: 4,
              dotData:
                  const FlDotData(show: true),
              spots: spots,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSyncButton() {
    return IconButton(
      icon: isSyncing
          ? const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : const Icon(
              Icons.cloud_sync,
            ),
      tooltip: "Sync from Backend",
      onPressed:
          isSyncing ? null : _syncFromBackend,
    );
  }

  Widget _buildUploadButton() {
    return IconButton(
      icon: isSyncing
          ? const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : const Icon(
              Icons.cloud_upload,
            ),
      tooltip: "Upload Local History",
      onPressed:
          isSyncing ? null : _migrateLocalHistory,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("History"),
          actions: [
            _buildSyncButton(),
            _buildUploadButton(),
          ],
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (sessions.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("History"),
          actions: [
            _buildSyncButton(),
            _buildUploadButton(),
          ],
        ),
        body: Center(
          child: Padding(
            padding:
                const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.history,
                  size: 70,
                  color: Colors.grey,
                ),
                const SizedBox(height: 16),
                const Text(
                  "No history yet.",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  "No backend sessions are currently available.\n"
                  "You can sync from the backend or upload "
                  "older sessions stored on this device.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      onPressed: isSyncing
                          ? null
                          : _syncFromBackend,
                      icon: const Icon(
                        Icons.cloud_sync,
                      ),
                      label: const Text(
                        "Sync",
                      ),
                    ),
                    const SizedBox(width: 12),
                    OutlinedButton.icon(
                      onPressed: isSyncing
                          ? null
                          : _migrateLocalHistory,
                      icon: const Icon(
                        Icons.cloud_upload,
                      ),
                      label: const Text(
                        "Upload Local",
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }

    final listToShow = filteredHistory;

    return Scaffold(
      appBar: AppBar(
        title: const Text("History"),
        actions: [
          _buildSyncButton(),
          _buildUploadButton(),

          IconButton(
            icon: const Icon(
              Icons.analytics,
            ),
            tooltip: "Performance Analytics",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const PerformanceAnalyticsScreen(),
                ),
              );
            },
          ),

          IconButton(
            icon: const Icon(
              Icons.compare_arrows,
            ),
            tooltip: "Compare Sessions",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const CompareSessionsScreen(),
                ),
              );
            },
          ),

          IconButton(
            icon: const Icon(
              Icons.delete,
            ),
            tooltip: "Clear Local Cache",
            onPressed:
                isSyncing ? null : _clearHistory,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            // --------------------------------------------------
            // ATHLETE FILTER
            // --------------------------------------------------

            Row(
              children: [
                const Text(
                  "Athlete:",
                  style: TextStyle(
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child:
                      DropdownButton<String>(
                    value: selectedAthlete,
                    isExpanded: true,
                    items: athleteList
                        .map(
                          (name) =>
                              DropdownMenuItem(
                            value: name,
                            child:
                                Text(name),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) {
                        return;
                      }

                      setState(() {
                        selectedAthlete =
                            value;
                      });
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            // --------------------------------------------------
            // ATHLETE DASHBOARD
            // --------------------------------------------------

            if (selectedAthlete != "All")
              SizedBox(
                width: double.infinity,
                child:
                    ElevatedButton.icon(
                  icon: const Icon(
                    Icons.person,
                  ),
                  label: const Text(
                    "Open Athlete Dashboard",
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            AthleteDashboard(
                          athlete:
                              selectedAthlete,
                        ),
                      ),
                    );
                  },
                ),
              ),

            const SizedBox(height: 12),

            // --------------------------------------------------
            // GRAPH
            // --------------------------------------------------

            _buildGraph(),

            const SizedBox(height: 12),

            // --------------------------------------------------
            // SESSION LIST
            // --------------------------------------------------

            Expanded(
              child:
                  RefreshIndicator(
                onRefresh: _syncFromBackend,
                child:
                    ListView.builder(
                  physics:
                      const AlwaysScrollableScrollPhysics(),
                  itemCount:
                      listToShow.length,
                  itemBuilder:
                      (context, index) {
                    final session =
                        listToShow[index];

                    final athlete =
                        session.athlete;

                    final time =
                        session.date;

                    final data =
                        session.metrics;

                    final knee =
                        data[
                                "average_knee_angle"]
                            ?.toString() ??
                        "N/A";

                    final level =
                        (
                          data[
                                  "performance_level"] ??
                              "unknown"
                        ).toString();

                    final score =
                        _calcScore(data);

                    final badgeColor =
                        _levelColor(
                      level,
                    );

                    return Card(
                      margin:
                          const EdgeInsets
                              .symmetric(
                        vertical: 6,
                      ),
                      child: ListTile(
                        leading:
                            CircleAvatar(
                          child: Text(
                            score
                                .toString(),
                          ),
                        ),
                        title: Text(
                          athlete,
                        ),
                        subtitle:
                            Text(
                          "Knee: $knee°\n"
                          "${time.day.toString().padLeft(2, '0')}/"
                          "${time.month.toString().padLeft(2, '0')}/"
                          "${time.year}",
                        ),
                        trailing:
                            Container(
                          padding:
                              const EdgeInsets
                                  .symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration:
                              BoxDecoration(
                            color: badgeColor
                                .withOpacity(
                              0.15,
                            ),
                            borderRadius:
                                BorderRadius
                                    .circular(
                              999,
                            ),
                            border:
                                Border.all(
                              color:
                                  badgeColor,
                            ),
                          ),
                          child: Text(
                            level
                                .toUpperCase(),
                            style: TextStyle(
                              color:
                                  badgeColor,
                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  ResultScreen(
                                resultData:
                                    data,
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}