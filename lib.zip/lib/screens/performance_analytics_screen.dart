import 'package:flutter/material.dart';

import '../models/session_model.dart';
import '../repositories/session_repository.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/performance_ai.dart';

class PerformanceAnalyticsScreen extends StatefulWidget {
  const PerformanceAnalyticsScreen({super.key});

  @override
  State<PerformanceAnalyticsScreen> createState() =>
      _PerformanceAnalyticsScreenState();
}

class _PerformanceAnalyticsScreenState
    extends State<PerformanceAnalyticsScreen> {
  final SessionRepository _repository = SessionRepository();

  List<SessionModel> sessions = [];

  double averageScore = 0;
  double bestScore = 0;
  DateTime? bestSessionDate;

String bestAthlete = "";
  double averageKneeAngle = 0;

  int totalSessions = 0;
  int beginnerCount = 0;
int intermediateCount = 0;
int advancedCount = 0;

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    final loaded = await _repository.getSessions();

    if (loaded.isEmpty) {
      setState(() {
        sessions = [];
        totalSessions = 0;
        averageScore = 0;
        bestScore = 0;
        averageKneeAngle = 0;
      });
      return;
    }

    double totalScore = 0;
    double totalKnee = 0;
    double best = 0;
    int beginner = 0;
int intermediate = 0;
int advanced = 0;

    for (final session in loaded) {
      final data = session.metrics;

      final score =
          double.tryParse(data["overall_score"].toString()) ?? 0;

      final knee =
          double.tryParse(
                data["average_knee_angle"].toString(),
              ) ??
              0;

      totalScore += score;
      totalKnee += knee;

      if (score > best) {
  best = score;

  bestSessionDate = session.date;

  bestAthlete = session.athlete;
}
final level =
    data["performance_level"]
        .toString()
        .toLowerCase();

switch (level) {
  case "beginner":
    beginner++;
    break;

  case "intermediate":
    intermediate++;
    break;

  case "advanced":
    advanced++;
    break;
}
    }

    setState(() {
      sessions = loaded;
      totalSessions = loaded.length;
      averageScore = totalScore / loaded.length;
      averageKneeAngle = totalKnee / loaded.length;
      bestScore = best;
      beginnerCount = beginner;
      intermediateCount = intermediate;
      advancedCount = advanced;
    });
  }
  Widget buildStatCard({
  required IconData icon,
  required String title,
  required String value,
  required Color color,
}) {
  return Card(
    elevation: 5,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
    ),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: color.withOpacity(.15),
            child: Icon(
              icon,
              color: color,
              size: 30,
            ),
          ),

          const SizedBox(width: 18),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 15,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}
Widget buildTrendChart() {
  if (sessions.length < 2) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Center(
          child: Text(
            "Run at least 2 sessions to view performance trends.",
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }

  final spots = <FlSpot>[];

  for (int i = 0; i < sessions.length; i++) {
    final score = double.tryParse(
          sessions[i].metrics["overall_score"].toString(),
        ) ??
        0;

    spots.add(
      FlSpot(i.toDouble(), score),
    );
  }

  return Card(
    elevation: 4,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: SizedBox(
        height: 250,
        child: LineChart(
          LineChartData(
            minY: 0,
            maxY: 100,

            gridData: FlGridData(show: true),

            borderData: FlBorderData(show: false),

            titlesData: FlTitlesData(
              rightTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              topTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  getTitlesWidget: (value, meta) {
                    return Text(
                      "S${value.toInt() + 1}",
                    );
                  },
                ),
              ),
            ),

            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: true,
                barWidth: 4,
                dotData: FlDotData(show: true),
                belowBarData: BarAreaData(show: true),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
Widget buildPersonalBestCard() {
  return Card(
    elevation: 5,
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          const Row(
            children: [
              Icon(
                Icons.workspace_premium,
                color: Colors.orange,
              ),
              SizedBox(width: 8),
              Text(
                "Personal Best",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Text(
            "Best Score : ${bestScore.toStringAsFixed(1)}",
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          Text(
            "Athlete : $bestAthlete",
            style: const TextStyle(fontSize: 18),
          ),

          const SizedBox(height: 8),

          Text(
            "Date : ${bestSessionDate?.day}/${bestSessionDate?.month}/${bestSessionDate?.year}",
            style: const TextStyle(fontSize: 18),
          ),
        ],
      ),
    ),
  );
}

Widget buildPerformanceDistribution() {
  return Card(
    elevation: 5,
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          const Text(
            "Performance Distribution",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 250,
            child: PieChart(
              PieChartData(
                sections: [

                  PieChartSectionData(
                    value: beginnerCount.toDouble(),
                    title: "Beginner",
                    color: Colors.red,
                    radius: 70,
                  ),

                  PieChartSectionData(
                    value: intermediateCount.toDouble(),
                    title: "Intermediate",
                    color: Colors.orange,
                    radius: 70,
                  ),

                  PieChartSectionData(
                    value: advancedCount.toDouble(),
                    title: "Advanced",
                    color: Colors.green,
                    radius: 70,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
Widget buildAIInsights() {
  final insights = PerformanceAI.generateInsights(
    averageScore: averageScore,
    bestScore: bestScore,
    averageKneeAngle: averageKneeAngle,
    totalSessions: totalSessions,
  );

  return Card(
    elevation: 5,
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.psychology,
                color: Colors.deepPurple,
              ),
              SizedBox(width: 10),
              Text(
                "AI Insights",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          ...insights.map(
            (e) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.smart_toy,
                    color: Colors.deepPurple,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      e,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Performance Analytics"),
      ),
      body: ListView(
  padding: const EdgeInsets.all(16),
  children: [

    buildStatCard(
      icon: Icons.emoji_events,
      title: "Best Score",
      value: bestScore.toStringAsFixed(1),
      color: Colors.orange,
    ),

    buildStatCard(
      icon: Icons.trending_up,
      title: "Average Score",
      value: averageScore.toStringAsFixed(1),
      color: Colors.green,
    ),

    buildStatCard(
      icon: Icons.accessibility_new,
      title: "Average Knee Angle",
      value: "${averageKneeAngle.toStringAsFixed(1)}°",
      color: Colors.blue,
    ),

    buildStatCard(
      icon: Icons.history,
      title: "Total Sessions",
      value: "$totalSessions",
      color: Colors.purple,
    ),
    const SizedBox(height: 20),

const Text(
  "Performance Trend",
  style: TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.bold,
  ),
),

const SizedBox(height: 12),

buildTrendChart(),

const SizedBox(height: 20),

buildPersonalBestCard(),

const SizedBox(height: 20),

buildPerformanceDistribution(),
const SizedBox(height: 20),

buildAIInsights(),
  ],
),
    );
  }
}