import 'package:flutter/material.dart';

import '../models/session_model.dart';
import '../repositories/session_repository.dart';
import '../utils/session_comparison.dart';
import 'compare_screen.dart';
import 'compare_sessions_screen.dart';

class CoachDashboard extends StatefulWidget {
const CoachDashboard({super.key});

@override
State<CoachDashboard> createState() => _CoachDashboardState();
}

class _CoachDashboardState extends State<CoachDashboard> {
final SessionRepository _repository = SessionRepository();

List<SessionModel> sessions = [];
bool isLoading = true;

@override
void initState() {
super.initState();
loadSessions();
}

Future<void> loadSessions() async {
try {
final data = await _repository.getSessions();


  if (!mounted) return;

  setState(() {
    sessions = data;
    isLoading = false;
  });
} catch (e) {
  if (!mounted) return;

  setState(() {
    isLoading = false;
    sessions = [];
  });

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('Unable to load coach dashboard: $e'),
    ),
  );
}


}

double getDouble(Map<String, dynamic> map, String key) {
return double.tryParse(
map[key]?.toString() ?? '',
) ??
0;
}

double scoreOf(SessionModel session) {
return getDouble(
session.metrics,
'overall_score',
);
}

double get averageScore {
if (sessions.isEmpty) return 0;


double total = 0;

for (final session in sessions) {
  total += scoreOf(session);
}

return total / sessions.length;


}

double get bestScore {
if (sessions.isEmpty) return 0;


double best = 0;

for (final session in sessions) {
  final score = scoreOf(session);

  if (score > best) {
    best = score;
  }
}

return best;


}

Set<String> get athletes {
return sessions
.map((session) => session.athlete)
.where((name) => name.trim().isNotEmpty)
.toSet();
}

SessionModel? get bestSession {
if (sessions.isEmpty) return null;


SessionModel best = sessions.first;

for (final session in sessions) {
  if (scoreOf(session) > scoreOf(best)) {
    best = session;
  }
}

return best;


}

Color scoreColor(double score) {
if (score >= 90) return Colors.green;
if (score >= 75) return Colors.orange;
return Colors.red;
}

String performanceLevel(double score) {
if (score >= 90) return 'Excellent';
if (score >= 75) return 'Good';
if (score >= 60) return 'Needs Work';
return 'Needs Attention';
}

double sessionKneeMechanics(SessionModel session) {
final knee = getDouble(
session.metrics,
'average_knee_angle',
);


return SessionComparison.calculateKneeMechanicScore(
  knee,
);


}

double sessionEfficiency(SessionModel session) {
final score = scoreOf(session);


final confidence = getDouble(
  session.metrics,
  'confidence',
);

return SessionComparison.calculateEfficiency(
  score,
  confidence,
);


}

double sessionTechnique(SessionModel session) {
final score = scoreOf(session);


final knee = getDouble(
  session.metrics,
  'average_knee_angle',
);

return SessionComparison.calculateTechnique(
  score,
  knee,
);


}

double sessionWeightedScore(SessionModel session) {
final score = scoreOf(session);


final knee = getDouble(
  session.metrics,
  'average_knee_angle',
);

final confidence = getDouble(
  session.metrics,
  'confidence',
);

final frames = getDouble(
  session.metrics,
  'frames',
);

final kneeMechanics =
    SessionComparison.calculateKneeMechanicScore(knee);

final efficiency =
    SessionComparison.calculateEfficiency(
  score,
  confidence,
);

final consistency =
    SessionComparison.calculateConsistency(
  frames,
  confidence,
);

final technique =
    SessionComparison.calculateTechnique(
  score,
  knee,
);

return SessionComparison.weightedScore(
  overallScore: score,
  kneeMechanics: kneeMechanics,
  technique: technique,
  efficiency: efficiency,
  consistency: consistency,
  confidence: confidence,
);


}

Widget statCard({
required IconData icon,
required String title,
required String value,
required Color color,
}) {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(18),
),
child: Padding(
padding: const EdgeInsets.all(18),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
CircleAvatar(
radius: 24,
backgroundColor: color.withOpacity(0.12),
child: Icon(
icon,
color: color,
size: 27,
),
),
const SizedBox(height: 10),
Text(
value,
style: TextStyle(
fontSize: 25,
fontWeight: FontWeight.bold,
color: color,
),
),
const SizedBox(height: 5),
Text(
title,
textAlign: TextAlign.center,
style: const TextStyle(
fontWeight: FontWeight.w600,
fontSize: 13,
),
),
],
),
),
);
}

Widget sectionTitle(
String title,
String subtitle,
) {
return Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
title,
style: const TextStyle(
fontSize: 21,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 4),
Text(
subtitle,
style: const TextStyle(
color: Colors.grey,
fontSize: 13,
),
),
],
);
}

Widget buildTopPerformer() {
final session = bestSession;


if (session == null) {
  return const Card(
    child: Padding(
      padding: EdgeInsets.all(20),
      child: Text(
        'No athlete sessions available yet.',
      ),
    ),
  );
}

final score = scoreOf(session);

return Card(
  elevation: 5,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(20),
  ),
  child: Padding(
    padding: const EdgeInsets.all(20),
    child: Row(
      children: [
        CircleAvatar(
          radius: 32,
          backgroundColor: Colors.amber.shade100,
          child: const Icon(
            Icons.emoji_events,
            color: Colors.orange,
            size: 38,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              const Text(
                'Top Performer',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                session.athlete,
                style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'Score ${score.toStringAsFixed(1)} • '
                '${performanceLevel(score)}',
                style: TextStyle(
                  color: scoreColor(score),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  ),
);


}

Widget buildAthleteCard(String athlete) {
final athleteSessions = sessions
.where(
(session) => session.athlete == athlete,
)
.toList();


if (athleteSessions.isEmpty) {
  return const SizedBox();
}

final latest = athleteSessions.first;
final latestScore = scoreOf(latest);

double best = 0;

for (final session in athleteSessions) {
  final score = scoreOf(session);

  if (score > best) {
    best = score;
  }
}

double improvement = 0;

if (athleteSessions.length >= 2) {
  final previous = scoreOf(
    athleteSessions[1],
  );

  if (previous != 0) {
    improvement =
        ((latestScore - previous) / previous) * 100;
  }
}

final weighted = sessionWeightedScore(latest);
final kneeMechanics = sessionKneeMechanics(latest);
final technique = sessionTechnique(latest);
final efficiency = sessionEfficiency(latest);

return Card(
  elevation: 3,
  margin: const EdgeInsets.only(bottom: 10),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(16),
  ),
  child: ExpansionTile(
    leading: CircleAvatar(
      backgroundColor:
          scoreColor(latestScore).withOpacity(0.12),
      child: Icon(
        Icons.person,
        color: scoreColor(latestScore),
      ),
    ),
    title: Text(
      athlete,
      style: const TextStyle(
        fontWeight: FontWeight.bold,
      ),
    ),
    subtitle: Text(
      '${athleteSessions.length} sessions • '
      '${performanceLevel(latestScore)}',
    ),
    trailing: Text(
      latestScore.toStringAsFixed(1),
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: scoreColor(latestScore),
      ),
    ),
    childrenPadding: const EdgeInsets.fromLTRB(
      16,
      0,
      16,
      16,
    ),
    children: [
      const Divider(),
      const SizedBox(height: 8),

      Row(
        children: [
          Expanded(
            child: _smallMetric(
              'Best',
              best.toStringAsFixed(1),
              Icons.emoji_events,
            ),
          ),
          Expanded(
            child: _smallMetric(
              'Latest',
              latestScore.toStringAsFixed(1),
              Icons.analytics,
            ),
          ),
          Expanded(
            child: _smallMetric(
              'Change',
              '${improvement.toStringAsFixed(1)}%',
              improvement >= 0
                  ? Icons.trending_up
                  : Icons.trending_down,
            ),
          ),
        ],
      ),

      const SizedBox(height: 18),

      _progressMetric(
        'Technique',
        technique,
        Icons.directions_run,
      ),

      _progressMetric(
        'Knee Mechanics',
        kneeMechanics,
        Icons.accessibility_new,
      ),

      _progressMetric(
        'Efficiency',
        efficiency,
        Icons.speed,
      ),

      _progressMetric(
        'Weighted Score',
        weighted,
        Icons.star,
      ),

      const SizedBox(height: 8),

      Align(
        alignment: Alignment.centerLeft,
        child: Text(
          latestScore >= 90
              ? 'Coach recommendation: Maintain current form and focus on consistency.'
              : latestScore >= 75
                  ? 'Coach recommendation: Good performance. Focus on technique and consistency.'
                  : 'Coach recommendation: Prioritize technique, knee mechanics, and running consistency.',
          style: const TextStyle(
            fontSize: 13,
            height: 1.4,
            color: Colors.black87,
          ),
        ),
      ),
    ],
  ),
);


}

Widget _smallMetric(
String title,
String value,
IconData icon,
) {
return Column(
children: [
Icon(
icon,
size: 19,
color: Colors.blueGrey,
),
const SizedBox(height: 4),
Text(
value,
style: const TextStyle(
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 2),
Text(
title,
style: const TextStyle(
fontSize: 11,
color: Colors.grey,
),
),
],
);
}

Widget _progressMetric(
String title,
double value,
IconData icon,
) {
final safeValue = value.clamp(0, 100).toDouble();


return Padding(
  padding: const EdgeInsets.only(top: 10),
  child: Column(
    children: [
      Row(
        children: [
          Icon(
            icon,
            size: 18,
            color: Colors.blueGrey,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            safeValue.toStringAsFixed(1),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
      const SizedBox(height: 5),
      LinearProgressIndicator(
        value: safeValue / 100,
        minHeight: 7,
        borderRadius: BorderRadius.circular(10),
      ),
    ],
  ),
);


}

Widget buildRecentActivity() {
if (sessions.isEmpty) {
return const Card(
child: Padding(
padding: EdgeInsets.all(20),
child: Text(
'No recent activity.',
),
),
);
}


final count = sessions.length > 5
    ? 5
    : sessions.length;

return Column(
  children: List.generate(
    count,
    (index) {
      final session = sessions[index];
      final score = scoreOf(session);

      return Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor:
                scoreColor(score).withOpacity(0.12),
            child: Icon(
              Icons.directions_run,
              color: scoreColor(score),
            ),
          ),
          title: Text(
            session.athlete,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: Text(
            '${session.date.day}/'
            '${session.date.month}/'
            '${session.date.year}',
          ),
          trailing: Column(
            mainAxisAlignment:
                MainAxisAlignment.center,
            crossAxisAlignment:
                CrossAxisAlignment.end,
            children: [
              Text(
                score.toStringAsFixed(1),
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: scoreColor(score),
                ),
              ),
              Text(
                performanceLevel(score),
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      );
    },
  ),
);


}

Widget buildCoachInsight() {
if (sessions.isEmpty) {
return const Card(
child: Padding(
padding: EdgeInsets.all(18),
child: Row(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Icon(
Icons.psychology,
color: Colors.deepPurple,
size: 32,
),
SizedBox(width: 12),
Expanded(
child: Text(
'Run an athlete analysis to generate coaching insights.',
style: TextStyle(
fontSize: 15,
height: 1.5,
),
),
),
],
),
),
);
}


String message;

if (bestScore >= 90 && averageScore >= 80) {
  message =
      'The team is performing at a strong level. '
      'Focus on maintaining consistency and identifying '
      'small technique improvements that can produce further gains.';
} else if (averageScore >= 75) {
  message =
      'Overall team performance is good. '
      'Give additional coaching attention to athletes '
      'performing below the team average.';
} else {
  message =
      'The team has significant room for improvement. '
      'Prioritize running mechanics, knee positioning, '
      'technique, and consistency in upcoming sessions.';
}

return Card(
  elevation: 4,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(18),
  ),
  child: Padding(
    padding: const EdgeInsets.all(18),
    child: Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        const Icon(
          Icons.psychology,
          color: Colors.deepPurple,
          size: 32,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            message,
            style: const TextStyle(
              fontSize: 15,
              height: 1.5,
            ),
          ),
        ),
      ],
    ),
  ),
);


}

@override
Widget build(BuildContext context) {
if (isLoading) {
return const Scaffold(
body: Center(
child: CircularProgressIndicator(),
),
);
}

return Scaffold(
  backgroundColor: Colors.grey.shade100,
  appBar: AppBar(
    title: const Text(
      'Coach Dashboard',
    ),
    centerTitle: true,
    actions: [
      IconButton(
        onPressed: loadSessions,
        icon: const Icon(
          Icons.refresh,
        ),
        tooltip: 'Refresh',
      ),
    ],
  ),
  body: RefreshIndicator(
    onRefresh: loadSessions,
    child: SingleChildScrollView(
      physics:
          const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 6,
            shape: RoundedRectangleBorder(
              borderRadius:
                  BorderRadius.circular(20),
            ),
            child: Padding(
              padding:
                  const EdgeInsets.all(20),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 34,
                    backgroundColor:
                        Colors.blue.shade100,
                    child: const Icon(
                      Icons.sports,
                      size: 38,
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Coach Performance Center',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${athletes.length} athletes • '
                          '${sessions.length} sessions',
                          style: const TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 22),

          sectionTitle(
            'Team Overview',
            'High-level performance statistics',
          ),

          const SizedBox(height: 12),

          GridView.count(
            physics:
                const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            crossAxisCount: 2,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            childAspectRatio: 1.15,
            children: [
              statCard(
                icon: Icons.groups,
                title: 'Athletes',
                value:
                    athletes.length.toString(),
                color: Colors.blue,
              ),
              statCard(
                icon: Icons.analytics,
                title: 'Sessions',
                value:
                    sessions.length.toString(),
                color: Colors.deepPurple,
              ),
              statCard(
                icon: Icons.bar_chart,
                title: 'Average Score',
                value:
                    averageScore.toStringAsFixed(1),
                color: Colors.green,
              ),
              statCard(
                icon: Icons.emoji_events,
                title: 'Best Score',
                value:
                    bestScore.toStringAsFixed(1),
                color: Colors.orange,
              ),
            ],
          ),

          const SizedBox(height: 24),

          sectionTitle(
            'Top Performer',
            'Highest recorded overall score',
          ),

          const SizedBox(height: 10),

          buildTopPerformer(),

          const SizedBox(height: 24),

          sectionTitle(
            'Athlete Performance',
            'Tap an athlete to view detailed metrics',
          ),

          const SizedBox(height: 10),

          if (athletes.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'No athletes found.',
                ),
              ),
            )
          else
            ...athletes.map(
              buildAthleteCard,
            ),

          const SizedBox(height: 24),

          sectionTitle(
            'Coach Insight',
            'Automated performance interpretation',
          ),

          const SizedBox(height: 10),

          buildCoachInsight(),

          const SizedBox(height: 24),

          sectionTitle(
            'Recent Activity',
            'Latest athlete analyses',
          ),

          const SizedBox(height: 10),

          buildRecentActivity(),

          const SizedBox(height: 24),

          sectionTitle(
            'Coach Tools',
            'Use existing analysis tools',
          ),

          const SizedBox(height: 10),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
             onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const CompareSessionsScreen(),
        ),
      );
    },
              icon: const Icon(
                Icons.compare_arrows,
              ),
              label: const Text(
                'Compare Sessions',
              ),
            ),
          ),

          const SizedBox(height: 10),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: loadSessions,
              icon: const Icon(
                Icons.refresh,
              ),
              label: const Text(
                'Refresh Coach Data',
              ),
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    ),
  ),
);

}
}
