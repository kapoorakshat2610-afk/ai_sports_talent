import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';

class AthleteDashboard extends StatefulWidget {
  final String athlete;

  const AthleteDashboard({
    super.key,
    required this.athlete,
  });

  @override
  State<AthleteDashboard> createState() => _AthleteDashboardState();
}

class _AthleteDashboardState extends State<AthleteDashboard> {
  List<Map<String, dynamic>> sessions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList("history") ?? [];

    final parsed = <Map<String, dynamic>>[];

    for (final item in history) {
      try {
        final decoded = jsonDecode(item);

        if ((decoded["athlete"] ?? "") == widget.athlete) {
          parsed.add(Map<String, dynamic>.from(decoded));
        }
      } catch (_) {}
    }

    setState(() {
      sessions = parsed;
    });
  }

  Widget _statCard(String title, String value) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 16,
            horizontal: 8,
          ),
          child: Column(
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              Text(title),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTrendGraph(List<double> scores) {
    if (scores.length < 2) {
      return const SizedBox(
        height: 200,
        child: Center(
          child: Text("Need at least 2 sessions"),
        ),
      );
    }

    final spots = scores.asMap().entries.map((entry) {
      return FlSpot(
        entry.key.toDouble(),
        entry.value,
      );
    }).toList();

    return SizedBox(
      height: 260,
      child: LineChart(
        LineChartData(
          minY: 0,
          maxY: 100,
          gridData: FlGridData(show: true),
          borderData: FlBorderData(show: true),
          titlesData: FlTitlesData(show: true),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              barWidth: 4,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (sessions.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text("${widget.athlete} Dashboard"),
        ),
        body: const Center(
          child: Text("No sessions found"),
        ),
      );
    }

    final scores = sessions.map((session) {
      final data = Map<String, dynamic>.from(
        session["data"] ?? {},
      );

      return double.tryParse(
            data["overall_score"].toString(),
          ) ??
          0;
    }).toList();

    final totalSessions = scores.length;

    final averageScore =
        scores.reduce((a, b) => a + b) / scores.length;

    final bestScore =
        scores.reduce((a, b) => a > b ? a : b);

    final latestScore = scores.first;

    double improvement = 0;

    if (scores.length >= 2) {
      improvement = scores.first - scores.last;
    }

    double talentPotential =
        averageScore + (improvement * 0.5);

    if (talentPotential > 100) {
      talentPotential = 100;
    }

    if (talentPotential < 0) {
      talentPotential = 0;
    }

    String category;

    if (talentPotential >= 85) {
      category = "State Level Potential";
    } else if (talentPotential >= 70) {
      category = "District Level Potential";
    } else if (talentPotential >= 50) {
      category = "School Level Potential";
    } else {
      category = "Beginner Athlete";
    }
    List<String> strengths = [];
List<String> improvements = [];
List<String> recommendations = [];

if (averageScore < 50) {
  recommendations.add("Focus on basic running mechanics.");
}

if (bestScore < 70) {
  recommendations.add("Increase sprint training intensity.");
}

if (improvement <= 0) {
  recommendations.add("Follow a structured weekly training plan.");
}

if (totalSessions < 5) {
  recommendations.add("Train more consistently and record sessions.");
}

if (talentPotential >= 70) {
  recommendations.add("Start advanced agility and acceleration drills.");
}

if (recommendations.isEmpty) {
  recommendations.add("Maintain current training program.");
}
String priority;

if (talentPotential < 50) {
  priority = "HIGH";
} else if (talentPotential < 75) {
  priority = "MEDIUM";
} else {
  priority = "LOW";
}
if (averageScore >= 70) {
  strengths.add("Good overall performance");
} else {
  improvements.add("Improve running mechanics");
}

if (bestScore >= 80) {
  strengths.add("High peak performance");
} else {
  improvements.add("Increase maximum performance");
}

if (improvement > 0) {
  strengths.add("Positive performance trend");
} else {
  improvements.add("Maintain consistent improvement");
}

if (totalSessions >= 5) {
  strengths.add("Regular training consistency");
} else {
  improvements.add("Complete more training sessions");
}

    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.athlete} Dashboard"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    widget.athlete,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 16),

                  Row(
                    children: [
                      _statCard(
                        "Sessions",
                        totalSessions.toString(),
                      ),
                      _statCard(
                        "Avg",
                        averageScore.toStringAsFixed(0),
                      ),
                    ],
                  ),

                  Row(
                    children: [
                      _statCard(
                        "Best",
                        bestScore.toStringAsFixed(0),
                      ),
                      _statCard(
                        "Latest",
                        latestScore.toStringAsFixed(0),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          const Text(
                            "Improvement",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "${improvement.toStringAsFixed(1)}",
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Divider(),

                  const SizedBox(height: 10),

                  const Text(
                    "Talent Potential",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "${talentPotential.toStringAsFixed(0)}/100",
                    style: const TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    category,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 20),

const Align(
  alignment: Alignment.centerLeft,
  child: Text(
    "Strengths",
    style: TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.bold,
      color: Colors.green,
    ),
  ),
),

const SizedBox(height: 8),

...strengths.map(
  (s) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        const Icon(
          Icons.check_circle,
          color: Colors.green,
          size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(s)),
      ],
    ),
  ),
),

const SizedBox(height: 20),

const Align(
  alignment: Alignment.centerLeft,
  child: Text(
    "Needs Improvement",
    style: TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.bold,
      color: Colors.orange,
    ),
  ),
),

const SizedBox(height: 8),

...improvements.map(
  (s) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        const Icon(
          Icons.warning_amber_rounded,
          color: Colors.orange,
          size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(s)),
      ],
    ),
  ),
),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),
          const SizedBox(height: 20),

const Divider(),

const SizedBox(height: 10),

const Text(
  "AI Coach Recommendations",
  style: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
  ),
),

const SizedBox(height: 10),

Text(
  "Priority: $priority",
  style: TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
  ),
),

const SizedBox(height: 12),

...recommendations.map(
  (r) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(
          Icons.psychology,
          size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(r),
        ),
      ],
    ),
  ),
),

          const Text(
            "Performance Trend",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          _buildTrendGraph(scores),
        ],
      ),
    );
  }
}