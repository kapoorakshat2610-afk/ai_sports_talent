import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../models/session_model.dart';
import '../repositories/session_repository.dart';
import '../utils/session_comparison.dart';

class CompareSessionsScreen extends StatefulWidget {
  const CompareSessionsScreen({super.key});

  @override
  State<CompareSessionsScreen> createState() =>
      _CompareSessionsScreenState();
}

class _CompareSessionsScreenState
    extends State<CompareSessionsScreen> {
  final SessionRepository _repository = SessionRepository();

  List<SessionModel> sessions = [];

  SessionModel? sessionA;
  SessionModel? sessionB;

  @override
  void initState() {
    super.initState();
    _loadSessions();
  }

  Future<void> _loadSessions() async {
  try {
    final loaded = await _repository.getSessions();

    if (!mounted) return;

    setState(() {
      sessions = loaded;

      if (loaded.length >= 2) {
        sessionA = loaded[0];
        sessionB = loaded[1];
      } else if (loaded.length == 1) {
        sessionA = loaded[0];
        sessionB = null;
      } else {
        sessionA = null;
        sessionB = null;
      }
    });
  } catch (e) {
    if (!mounted) return;

    setState(() {
      sessions = [];
      sessionA = null;
      sessionB = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "Unable to load sessions: $e",
        ),
      ),
    );
  }
}

  String _sessionTitle(SessionModel session) {
    final score = double.tryParse(
          session.metrics["overall_score"].toString(),
        ) ??
        0;

    final d = session.date;

    return "${session.athlete} • "
        "${d.day.toString().padLeft(2, "0")}/"
        "${d.month.toString().padLeft(2, "0")}/"
        "${d.year} • "
        "Score ${score.toStringAsFixed(1)}";
  }

  double getDouble(
    Map<String, dynamic> map,
    String key,
  ) {
    return double.tryParse(
          map[key].toString(),
        ) ??
        0;
  }

  Widget buildSessionSelectors() {
    return Column(
      children: [
        DropdownButtonFormField<SessionModel>(
          value: sessionA,
          decoration: const InputDecoration(
            labelText: "Session A",
            border: OutlineInputBorder(),
          ),
          items: sessions
              .map(
                (e) => DropdownMenuItem(
                  value: e,
                  child: Text(_sessionTitle(e)),
                ),
              )
              .toList(),
          onChanged: (value) {
            setState(() {
              sessionA = value;
            });
          },
        ),
        const SizedBox(height: 15),
        DropdownButtonFormField<SessionModel>(
          value: sessionB,
          decoration: const InputDecoration(
            labelText: "Session B",
            border: OutlineInputBorder(),
          ),
          items: sessions
              .map(
                (e) => DropdownMenuItem(
                  value: e,
                  child: Text(_sessionTitle(e)),
                ),
              )
              .toList(),
          onChanged: (value) {
            setState(() {
              sessionB = value;
            });
          },
        ),
      ],
    );
  }

  Widget buildComparisonRow(
    String title,
    dynamic valueA,
    dynamic valueB,
  ) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(
              valueA.toString(),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            child: Text(
              valueB.toString(),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget buildComparisonTable() {
    if (sessionA == null || sessionB == null) {
      return const SizedBox();
    }

    final a = sessionA!.metrics;
    final b = sessionB!.metrics;

    final scoreA =
        getDouble(a, "overall_score");
    final scoreB =
        getDouble(b, "overall_score");

    final kneeA =
        getDouble(a, "average_knee_angle");
    final kneeB =
        getDouble(b, "average_knee_angle");

    final confidenceA =
        getDouble(a, "confidence");
    final confidenceB =
        getDouble(b, "confidence");

    final framesA =
        getDouble(a, "frames");
    final framesB =
        getDouble(b, "frames");

    final kneeMechanicsA =
        SessionComparison
            .calculateKneeMechanicScore(
      kneeA,
    );

    final kneeMechanicsB =
        SessionComparison
            .calculateKneeMechanicScore(
      kneeB,
    );

    final efficiencyA =
        SessionComparison
            .calculateEfficiency(
      scoreA,
      confidenceA,
    );

    final efficiencyB =
        SessionComparison
            .calculateEfficiency(
      scoreB,
      confidenceB,
    );

    final consistencyA =
        SessionComparison
            .calculateConsistency(
      framesA,
      confidenceA,
    );

    final consistencyB =
        SessionComparison
            .calculateConsistency(
      framesB,
      confidenceB,
    );

    final techniqueA =
        SessionComparison
            .calculateTechnique(
      scoreA,
      kneeA,
    );

    final techniqueB =
        SessionComparison
            .calculateTechnique(
      scoreB,
      kneeB,
    );

    final weightedA =
        SessionComparison.weightedScore(
      overallScore: scoreA,
      kneeMechanics: kneeMechanicsA,
      technique: techniqueA,
      efficiency: efficiencyA,
      consistency: consistencyA,
      confidence: confidenceA,
    );

    final weightedB =
        SessionComparison.weightedScore(
      overallScore: scoreB,
      kneeMechanics: kneeMechanicsB,
      technique: techniqueB,
      efficiency: efficiencyB,
      consistency: consistencyB,
      confidence: confidenceB,
    );

    final winnerName =
        SessionComparison.isSessionABetter(
      weightedA,
      weightedB,
    )
            ? sessionA!.athlete
            : sessionB!.athlete;

    final winnerScore =
        SessionComparison.isSessionABetter(
      weightedA,
      weightedB,
    )
            ? weightedA
            : weightedB;

    final improvement =
        ((weightedB - weightedA) /
                (weightedA == 0
                    ? 1
                    : weightedA)) *
            100;

    final aiSummary =
        SessionComparison.generateSummary(
      scoreA: scoreA,
      scoreB: scoreB,
      kneeA: kneeA,
      kneeB: kneeB,
      confidenceA: confidenceA,
      confidenceB: confidenceB,
    );

    // ===== CONTINUE IN PART 2 =====
        return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildWinnerCard(
          winnerName,
          winnerScore,
          improvement,
        ),

        const SizedBox(height: 20),

        buildAISummary(aiSummary),

        const SizedBox(height: 20),

        buildRadarChart(
          scoreA: scoreA,
          scoreB: scoreB,
          kneeMechanicsA: kneeMechanicsA,
          kneeMechanicsB: kneeMechanicsB,
          techniqueA: techniqueA,
          techniqueB: techniqueB,
          efficiencyA: efficiencyA,
          efficiencyB: efficiencyB,
          consistencyA: consistencyA,
          consistencyB: consistencyB,
          confidenceA: confidenceA,
          confidenceB: confidenceB,
        ),

        const SizedBox(height: 25),

        const Text(
          "Performance Comparison",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),

        const Divider(),

        buildComparisonRow(
          "Overall Score",
          scoreA.toStringAsFixed(1),
          scoreB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Average Knee Angle",
          kneeA.toStringAsFixed(1),
          kneeB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Confidence",
          confidenceA.toStringAsFixed(1),
          confidenceB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Technique",
          techniqueA.toStringAsFixed(1),
          techniqueB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Efficiency",
          efficiencyA.toStringAsFixed(1),
          efficiencyB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Consistency",
          consistencyA.toStringAsFixed(1),
          consistencyB.toStringAsFixed(1),
        ),

        buildComparisonRow(
          "Weighted Score",
          weightedA.toStringAsFixed(1),
          weightedB.toStringAsFixed(1),
        ),

        const SizedBox(height: 25),

        buildExportButtons(
          winnerName,
          winnerScore,
          aiSummary,
        ),
      ],
    );
  }

  Widget buildWinnerCard(
    String winnerName,
    double winnerScore,
    double improvement,
  ) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.emoji_events,
              color: Colors.amber,
              size: 55,
            ),

            const SizedBox(height: 12),

            const Text(
              "Winner",
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              winnerName,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              "Weighted Score : ${winnerScore.toStringAsFixed(1)}",
              style: const TextStyle(
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              improvement >= 0
                  ? "+${improvement.toStringAsFixed(1)}% Better"
                  : "${improvement.toStringAsFixed(1)}% Lower",
              style: TextStyle(
                color: improvement >= 0
                    ? Colors.green
                    : Colors.red,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildAISummary(String summary) {
    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.psychology),

                SizedBox(width: 10),

                Text(
                  "AI Summary",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),

            Text(
              summary,
              style: const TextStyle(
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildRadarChart({
    required double scoreA,
    required double scoreB,
    required double kneeMechanicsA,
    required double kneeMechanicsB,
    required double techniqueA,
    required double techniqueB,
    required double efficiencyA,
    required double efficiencyB,
    required double consistencyA,
    required double consistencyB,
    required double confidenceA,
    required double confidenceB,
  }) {
    return SizedBox(
      height: 340,
      child: RadarChart(
        RadarChartData(
          radarShape: RadarShape.circle,

          tickCount: 5,

          dataSets: [
            RadarDataSet(
              borderColor: Colors.blue,
              fillColor:
                  Colors.blue.withOpacity(.30),
              entryRadius: 3,
              dataEntries: [
                RadarEntry(value: scoreA),
                RadarEntry(
                    value: kneeMechanicsA),
                RadarEntry(value: techniqueA),
                RadarEntry(value: efficiencyA),
                RadarEntry(value: consistencyA),
                RadarEntry(value: confidenceA),
              ],
            ),

            RadarDataSet(
              borderColor: Colors.orange,
              fillColor:
                  Colors.orange.withOpacity(.30),
              entryRadius: 3,
              dataEntries: [
                RadarEntry(value: scoreB),
                RadarEntry(
                    value: kneeMechanicsB),
                RadarEntry(value: techniqueB),
                RadarEntry(value: efficiencyB),
                RadarEntry(value: consistencyB),
                RadarEntry(value: confidenceB),
              ],
            ),
          ],

          titleTextStyle:
              const TextStyle(fontSize: 12),

          getTitle: (
            int index,
            double angle,
          ) {
            switch (index) {
              case 0:
                return const RadarChartTitle(
                  text: "Overall",
                );

              case 1:
                return const RadarChartTitle(
                  text: "Knee",
                );

              case 2:
                return const RadarChartTitle(
                  text: "Technique",
                );

              case 3:
                return const RadarChartTitle(
                  text: "Efficiency",
                );

              case 4:
                return const RadarChartTitle(
                  text: "Consistency",
                );

              default:
                return const RadarChartTitle(
                  text: "Confidence",
                );
            }
          },
        ),
      ),
    );
  }
    Future<void> exportPdf(
    String winnerName,
    double winnerScore,
    String aiSummary,
  ) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (context) {
          return pw.Padding(
            padding: const pw.EdgeInsets.all(24),
            child: pw.Column(
              crossAxisAlignment:
                  pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  "Running Session Comparison Report",
                  style: pw.TextStyle(
                    fontSize: 22,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),

                pw.SizedBox(height: 20),

                pw.Text(
                  "Winner : $winnerName",
                ),

                pw.Text(
                  "Weighted Score : ${winnerScore.toStringAsFixed(1)}",
                ),

                pw.SizedBox(height: 20),

                pw.Text(
                  "AI Summary",
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),

                pw.SizedBox(height: 10),

                pw.Text(aiSummary),
              ],
            ),
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
    );
  }

  Future<void> shareReport(
    String winnerName,
    double winnerScore,
    String aiSummary,
  ) async {
    final report = """
Running Session Comparison

Winner : $winnerName

Weighted Score :
${winnerScore.toStringAsFixed(1)}

AI Summary

$aiSummary
""";

    await Share.share(report);
  }

  Widget buildExportButtons(
  String winnerName,
  double winnerScore,
  String aiSummary,
) {
  return Row(
    children: [
      Expanded(
        child: ElevatedButton.icon(
          onPressed: () {
            exportPdf(
              winnerName,
              winnerScore,
              aiSummary,
            );
          },
          icon: const Icon(Icons.picture_as_pdf),
          label: const Text("Export PDF"),
        ),
      ),

      const SizedBox(width: 15),

      Expanded(
        child: ElevatedButton.icon(
          onPressed: () {
            shareReport(
              winnerName,
              winnerScore,
              aiSummary,
            );
          },
          icon: const Icon(Icons.share),
          label: const Text("Share Report"),
        ),
      ),
    ],
  );
}

 @override
Widget build(BuildContext context) {
  if (sessions.isEmpty) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Compare Sessions",
        ),
      ),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            "No sessions available.\n\n"
            "Run an analysis to create your first session.",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  if (sessions.length < 2) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Compare Sessions",
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.compare_arrows,
                size: 70,
                color: Colors.grey,
              ),
              const SizedBox(height: 20),
              const Text(
                "Not enough sessions",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "You currently have 1 saved session.\n"
                "Run another analysis to compare two sessions.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _loadSessions,
                icon: const Icon(Icons.refresh),
                label: const Text(
                  "Refresh Sessions",
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  return Scaffold(
    appBar: AppBar(
      title: const Text(
        "Compare Sessions",
      ),
      centerTitle: true,
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          buildSessionSelectors(),

          const SizedBox(height: 20),

          if (sessionA == null ||
              sessionB == null)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  "Select two different sessions to compare.",
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            buildComparisonTable(),
        ],
      ),
    ),
  );
}
  
}