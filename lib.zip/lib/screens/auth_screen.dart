import 'package:flutter/material.dart';

import '../services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final AuthService _authService = AuthService();

  final TextEditingController _usernameController =
      TextEditingController();

  final TextEditingController _emailController =
      TextEditingController();

  final TextEditingController _passwordController =
      TextEditingController();

  bool isLogin = true;
  bool isLoading = false;
  bool obscurePassword = true;

  String selectedRole = 'athlete';

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final username =
        _usernameController.text.trim();

    final email =
        _emailController.text.trim();

    final password =
        _passwordController.text;

    if (username.isEmpty) {
      _showMessage('Please enter username.');
      return;
    }

    if (!isLogin && email.isEmpty) {
      _showMessage('Please enter email.');
      return;
    }

    if (password.isEmpty) {
      _showMessage('Please enter password.');
      return;
    }

    if (password.length < 6) {
      _showMessage(
        'Password must contain at least 6 characters.',
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      if (isLogin) {
        await _authService.login(
          username: username,
          password: password,
        );
      } else {
        await _authService.register(
          username: username,
          email: email,
          password: password,
          role: selectedRole,
        );

        await _authService.login(
          username: username,
          password: password,
        );
      }

      if (!mounted) return;

      final role =
          await _authService.getRole();

      setState(() {
        isLoading = false;
      });

      _showMessage(
        'Login successful.',
        isError: false,
      );

      Navigator.pushReplacementNamed(
        context,
        role == 'coach'
            ? '/coach'
            : '/app',
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      _showMessage(
        e.toString().replaceFirst(
              'Exception: ',
              '',
            ),
      );
    }
  }

  void _showMessage(
    String message, {
    bool isError = true,
  }) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor:
              isError ? Colors.red : Colors.green,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          isLogin ? 'Login' : 'Create Account',
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),

              const Icon(
                Icons.sports,
                size: 70,
              ),

              const SizedBox(height: 20),

              Text(
                'AI Sports Talent',
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),

              const SizedBox(height: 8),

              Text(
                isLogin
                    ? 'Sign in to continue'
                    : 'Create your athlete or coach account',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 30),

              TextField(
                controller:
                    _usernameController,
                textInputAction:
                    TextInputAction.next,
                decoration:
                    const InputDecoration(
                  labelText: 'Username',
                  border:
                      OutlineInputBorder(),
                  prefixIcon:
                      Icon(Icons.person),
                ),
              ),

              const SizedBox(height: 15),

              if (!isLogin) ...[
                TextField(
                  controller:
                      _emailController,
                  keyboardType:
                      TextInputType.emailAddress,
                  textInputAction:
                      TextInputAction.next,
                  decoration:
                      const InputDecoration(
                    labelText: 'Email',
                    border:
                        OutlineInputBorder(),
                    prefixIcon:
                        Icon(Icons.email),
                  ),
                ),

                const SizedBox(height: 15),

                DropdownButtonFormField<String>(
                  initialValue: selectedRole,
                  decoration:
                      const InputDecoration(
                    labelText: 'Role',
                    border:
                        OutlineInputBorder(),
                    prefixIcon:
                        Icon(Icons.badge),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'athlete',
                      child: Text('Athlete'),
                    ),
                    DropdownMenuItem(
                      value: 'coach',
                      child: Text('Coach'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value == null) return;

                    setState(() {
                      selectedRole = value;
                    });
                  },
                ),

                const SizedBox(height: 15),
              ],

              TextField(
                controller:
                    _passwordController,
                obscureText:
                    obscurePassword,
                decoration:
                    InputDecoration(
                  labelText: 'Password',
                  border:
                      const OutlineInputBorder(),
                  prefixIcon:
                      const Icon(Icons.lock),
                  suffixIcon:
                      IconButton(
                    onPressed: () {
                      setState(() {
                        obscurePassword =
                            !obscurePassword;
                      });
                    },
                    icon: Icon(
                      obscurePassword
                          ? Icons
                              .visibility
                          : Icons
                              .visibility_off,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed:
                      isLoading
                          ? null
                          : _submit,
                  child: isLoading
                      ? const SizedBox(
                          height: 24,
                          width: 24,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          isLogin
                              ? 'Login'
                              : 'Create Account',
                        ),
                ),
              ),

              const SizedBox(height: 15),

              TextButton(
                onPressed: isLoading
                    ? null
                    : () {
                        setState(() {
                          isLogin =
                              !isLogin;
                        });
                      },
                child: Text(
                  isLogin
                      ? 'Create a new account'
                      : 'Already have an account? Login',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}